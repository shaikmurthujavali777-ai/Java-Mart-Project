
import java.util.ArrayList;
import P8.Softdrinks;
public class S extends Softdrinks{
	public static final String G = "\u001B[32m";
	public static final String RT = "\u001B[0m";	
	@Override
	public void sevenup(){
		System.out.println(G+"1litre 7UP bottle added"+RT);
		F.f.item.add("7up");
		F.f.cost.add(45);
	}
	@Override
	public void sprite(){
		System.out.println(G+"1litre sprite bottle added"+RT);
		F.f.item.add("sprite");
		F.f.cost.add(40);
	}
	@Override
	public void coco_cola(){
		System.out.println(G+"1litre coco_cola bottle added"+RT);
		F.f.item.add("coco_cola");
		F.f.cost.add(50);
	}
	@Override
	public void thumbsup(){
		System.out.println(G+"1litre thumbsup bottle added"+RT);
		F.f.item.add("thumbsup");
		F.f.cost.add(45);
	}
	@Override
	public void fanta(){
		System.out.println(G+"1litre fanta bottle added"+RT);
		F.f.item.add("fanta");
		F.f.cost.add(65);
	}

	@Override
	public void mirnda(){
		System.out.println(G+"1litre 7UP bottle added"+RT);
		F.f.item.add("mirnda");
		F.f.cost.add(55);
	}
	@Override
	public void mountain_dew(){
		System.out.println(G+"1litre mountain_dew bottle added"+RT);
		F.f.item.add("mountain_dew");
		F.f.cost.add(55);
	}

	@Override
	public void pepsi(){
		System.out.println(G+"1litre pepsi bottle added"+RT);
		F.f.item.add("pepsi");
		F.f.cost.add(45);
	}
	@Override
	public void coconut_water(){
		System.out.println(G+"1litre coconut_water bottle added"+RT);
		F.f.item.add("coconut_water");
		F.f.cost.add(120);
	}
	@Override
	public void redbull(){
		System.out.println(G+"1can redbull  added"+RT);
		F.f.item.add("redbull");
		F.f.cost.add(115);
	}
	@Override
	public void Monster(){
		System.out.println(G+"1can Monster  added"+RT);
		F.f.item.add("Monster");
		F.f.cost.add(90);
	}
	@Override
	public void Coolberg(){
		System.out.println(G+"1litre Coolberg bottle added"+RT);
		F.f.item.add("Coolberg");
		F.f.cost.add(92);
	}
	@Override
	public void Maaza(){
		System.out.println(G+"1litre Maaza bottle added"+RT);
		F.f.item.add("Maaza");
		F.f.cost.add(45);
	}
	@Override
	public void pulpyOrange(){
		System.out.println(G+"1litre pulpyOrange bottle added"+RT);
		F.f.item.add("pulpyOrange");
		F.f.cost.add(75);
	}
	@Override
	public void Amullassi(){
		System.out.println(G+"250ml Amullassi bottle added"+RT);
		F.f.item.add("Amullaasi");
		F.f.cost.add(35);
	}
	@Override
	public void KinleyStrongSoda(){
		System.out.println(G+"1litre KinleyStrongSoda bottle added"+RT);
		F.f.item.add("KinleyStrongSoda");
		F.f.cost.add(72);
	}
	@Override
	public void Coco_cola_Zerosugar(){
		System.out.println(G+"250ml Coco_cola_Zerosugar bottle added"+RT);
		F.f.item.add("Coco_cola_Zerosugar");
		F.f.cost.add(45);
	}
	@Override
	public void Pepsi_ZeroSugar(){
		System.out.println(G+"250ml Pepsi_ZeroSugar bottle added"+RT);
		F.f.item.add("Pepsi_ZeroSugar");
		F.f.cost.add(52);
	}
	@Override
	public void Limca(){
		System.out.println(G+"1litre Limca bottle added"+RT);
		F.f.item.add("Limca");
		F.f.cost.add(40);
	}


}