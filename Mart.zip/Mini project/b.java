import java.util.ArrayList;
import P4.beauty_items;
public class b extends beauty_items{
	public static final String G = "\u001B[32m";
	public static final String RT = "\u001B[0m";
	@Override
	public void faceWash(){
		System.out.println(G+"100m1 Face Wash added"+RT);
		F.f.item.add("Face Wash");
		F.f.cost.add(500);
	}
	@Override
	public void moisturizer(){
		System.out.println(G+"80g Moisturizer added"+RT);
		F.f.item.add("Moisturizer");
		F.f.cost.add(250);
	}
	@Override
	public void sunscreen(){
		System.out.println(G+"80g Sunscreen added"+RT);
		F.f.item.add("Sunscreen");
		F.f.cost.add(500);
	}
	@Override
	public void exfoliatingScrub(){
		System.out.println(G+"200g Exfoliating Scrub added"+RT);
		F.f.item.add("Exfoliating Scrub");
		F.f.cost.add(200);
	}
	@Override
	public void facemaskpack(){
		System.out.println(G+"25ml Facemask pack added"+RT);
		F.f.item.add("Facemask pack");
		F.f.cost.add(150);
	}
	@Override
	public void toner(){
		System.out.println(G+"400ml Toner added"+RT);
		F.f.item.add("Toner");
		F.f.cost.add(150);
	}
	@Override
	public void serum(){
		System.out.println(G+"30ml Serum added"+RT);
		F.f.item.add("Serum");
		F.f.cost.add(526);
	}
	@Override
	public void shampoo(){
		System.out.println(G+"1.2litres Shampoo added"+RT);
		F.f.item.add("Shampoo");
		F.f.cost.add(575);
	}
	@Override
	public void conditioner(){
		System.out.println(G+"175ml Conditioner added"+RT);
		F.f.item.add("Conditioner");
		F.f.cost.add(240);
	}
	@Override
	public void hairOil(){
		System.out.println(G+"400ml Hair Oil added"+RT);
		F.f.item.add("Hair Oil");
		F.f.cost.add(200);
	}
	@Override
	public void  perfume(){
		System.out.println(G+"100ml Perfume added"+RT);
		F.f.item.add("Perfume");
		F.f.cost.add(280);
	}
	@Override
	public void straighteners(){
		System.out.println(G+"1piece Straighteners added"+RT);
		F.f.item.add("Straighteners");
		F.f.cost.add(2697);
	}
	@Override
	public void LipBalm(){
		System.out.println(G+"4.8g Lip Balm added"+RT);
		F.f.item.add("Lip Balm");
		F.f.cost.add(202);
	}
	@Override
	public void hairGel(){
		System.out.println(G+"50g Hair Gel added"+RT);
		F.f.item.add("Hair Gel");
		F.f.cost.add(110);
	}
	@Override
	public void eyebrowPencil(){
		System.out.println(G+"1piece Eyebrow Pencil added"+RT);
		F.f.item.add("Eyebrow Pencil");
		F.f.cost.add(456);
	}
	@Override
	public void eyeLiner(){
		System.out.println(G+"3.7g EyeLiner added"+RT);
		F.f.item.add("EyeLiner");
		F.f.cost.add(323);
	}
	@Override
	public void mascara(){
		System.out.println(G+"10ml Mascara added"+RT);
		F.f.item.add("Mascara");
		F.f.cost.add(274);
	}
	@Override
	public void lipstick(){
		System.out.println(G+"1.7g lipstick added"+RT);
		F.f.item.add("lipstick");
		F.f.cost.add(1649);
	}
	@Override
	public void  hairSerum(){
		System.out.println(G+"175ml Hair Serum added"+RT);
		F.f.item.add("Hair Serum");
		F.f.cost.add(837);
	}
	 @Override
	public void babyCream(){
		System.out.println(G+"100g Baby Cream added"+RT);
		F.f.item.add("Baby Cream");
		F.f.cost.add(523);
	}
}

