public class logo{
	public static void cvlogo(){
		//final String O = "\u001B[31m";
		final String R = "\u001B[38;5;208m";
		final String O= "\u001B[38;2;135;206;235m";
		final String RESET = "\u001B[0m";
		System.out.println(O+"\t\t\t\t\t\t\t\t\t\t%------------------------------------------------%");
		System.out.println(O+"\t\t\t\t\t\t\t\t\t\t|"+R+"   *****  *    *     *   *   ***   ****  *****  "+O+"|");
		System.out.println(O+"\t\t\t\t\t\t\t\t\t\t|"+R+"  *       *    *     ** **  *   *  *   *   *    "+O+"|");
		System.out.println(O+"\t\t\t\t\t\t\t\t\t\t|"+R+"  *       *    *     * * *  *****  ****    *    "+O+"|");
		System.out.println(O+"\t\t\t\t\t\t\t\t\t\t|"+R+"  *        *  *      *   *  *   *  *  *    *    "+O+"|");
		System.out.println(O+"\t\t\t\t\t\t\t\t\t\t|"+R+"   *****     *       *   *  *   *  *   *   *    "+O+"|");
		System.out.println(O+"\t\t\t\t\t\t\t\t\t\t%------------------------------------------------%"+RESET);
	}
}