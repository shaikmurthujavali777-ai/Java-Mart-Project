import java.util.ArrayList;
import P7.Homeessentials;
public class  H extends Homeessentials{
	public static final String G = "\u001B[32m";
	public static final String RT = "\u001B[0m";
	@Override
	public void chopper(){
		System.out.println(G+"250ml Chopper added"+RT);
		F.f.item.add("Chopper");
		F.f.cost.add(499);
	}
	@Override
	public void icetong(){
		System.out.println(G+"1pc Icetong added"+RT);
		F.f.item.add("Icetong");
		F.f.cost.add(81);
	}
	@Override
	public void steelknife(){
		System.out.println(G+"green knife Steelknife added"+RT);
		F.f.item.add("Steelknife");
		F.f.cost.add(299);
	}
	@Override
	public void wallmirror(){
		System.out.println(G+"4 pcs,35*30cm Wallmirror added"+RT);
		F.f.item.add("Wallmirror");
		F.f.cost.add(799);
	}
	@Override
	public void curtain(){
		System.out.println(G+"7ft cotton Curtain added"+RT);
		F.f.item.add("Curtain");
		F.f.cost.add(1902);
	}
	@Override
	public void pressurecooker(){
		System.out.println(G+"Butterfly,3 ltrs Pressurecooker added"+RT);
		F.f.item.add("Pressurecooker");
		F.f.cost.add(2499);
	}
	@Override
	public void spoonstand(){
		System.out.println(G+"wooden cutlery stand brown gold Spoonstand added"+RT);
		F.f.item.add("Spoonstand");
		F.f.cost.add(1499);
	}
	@Override
	public void nonsticktawa(){
		System.out.println(G+"Aluminium metal spoon Nonsticktawa added"+RT);
		F.f.item.add("Nonsticktawa");
		F.f.cost.add(599);
	}
	@Override
	public void glassbeermug(){
		System.out.println(G+"500ml Glassbeermug added"+RT);
		F.f.item.add("Glassbeermug");
		F.f.cost.add(999);
	}
	@Override
	public void bedsheet(){
		System.out.println(G+"130 TC cream Bedsheet added"+RT);
		F.f.item.add("Bedsheet");
		F.f.cost.add(499);
	}
	@Override
	public void lamp(){
		System.out.println(G+"3D Galaxy Ball Night Lamp added"+RT);
		F.f.item.add("Lamp");
		F.f.cost.add(699);
	}
	@Override
	public void wallclock(){
		System.out.println(G+"Titan white Wallclock added"+RT);
		F.f.item.add("Wallclock");
		F.f.cost.add(1259);
	}
	@Override
	public void ceramicplate(){
		System.out.println(G+"Black & White,2pc Creamicplate added"+RT);
		F.f.item.add("Creamicplate");
		F.f.cost.add(479);
	}
	@Override
	public void plantstand(){
		System.out.println(G+"leafy tales plant stand Plantstand added"+RT);
		F.f.item.add("Plantstand");
		F.f.cost.add(299);
	}
	@Override
	public void floorrug(){
		System.out.println(G+"cotton grey Floorrug added"+RT);
		F.f.item.add("Floorrug");
		F.f.cost.add(599);
	}
	@Override
	public void mattress(){
		System.out.println(G+"5 Inch Queen Size Mattress added"+RT);
		F.f.item.add("Mattress");
		F.f.cost.add(6929);
	}
	@Override
	public void storagecabinet(){
		System.out.println(G+"Multipurpose Storagecabinet added"+RT);
		F.f.item.add("Storagecabinet");
		F.f.cost.add(2199);
	}
	@Override
	public void diningtable(){
		System.out.println(G+"4 Seater Cane Matee Diningtable added"+RT);
		F.f.item.add("Diningtable");
		F.f.cost.add(1499);
	}
	@Override
	public void sofa(){
		System.out.println(G+"Wooden 3 seater Sofaset added"+RT);
		F.f.item.add("Sofa");
		F.f.cost.add(14499);
	}
	@Override
	public void officechair(){
		System.out.println(G+"2D Headrest,Grey-White Officechair added"+RT);
		F.f.item.add("Officechair");
		F.f.cost.add(5099);
	}
	@Override
	public void laptoptable(){
		System.out.println(G+"Black-60[L] * 40[W] Laptoptable added"+RT);
		F.f.item.add("Laptoptable");
		F.f.cost.add(449);
	}
	@Override
	public void oildispenser(){
		System.out.println(G+"500ml Oildispenser added"+RT);
		F.f.item.add("Oildispenser");
		F.f.cost.add(399);
	}
}



	