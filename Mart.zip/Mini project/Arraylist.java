import java.util.ArrayList;
public class Arraylist{
	public static ArrayList<String> item = new ArrayList<String>();
	public static ArrayList<Integer> cost= new ArrayList<Integer>();
}