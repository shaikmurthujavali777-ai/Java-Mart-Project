import java.util.ArrayList;
import P5.Snacks;
public class Sn extends Snacks{	
	public static final String G = "\u001B[32m";
	public static final String RT = "\u001B[0m";
	public void chips(){
		System.out.println(G+"1Pack Chips added"+RT);
		F.f.item.add("Chips");
		F.f.cost.add(51);
	}
	public void moongdal(){
		System.out.println(G+"1Pack Moongdal added"+RT);
		F.f.item.add("Moongdal");
		F.f.cost.add(60);
	}
	public void nuts(){
		System.out.println(G+"1Pack Nuts added"+RT);
		F.f.item.add("Nuts");
		F.f.cost.add(55);
	}
	public void snickers(){
		System.out.println(G+"1 Snickers added"+RT);
		F.f.item.add("Snickers");
		F.f.cost.add(76);
	}
	public void dairymilk(){
		System.out.println(G+"1 Dairymilk added"+RT);
		F.f.item.add("Dairymilk");
		F.f.cost.add(109);
	}
	public void popcorn(){
		System.out.println(G+"1Pack Popcorn added"+RT);
		F.f.item.add("Popcorn");
		F.f.cost.add(30);
	}
	public void soyasticks(){
		System.out.println(G+"1Pack Soyasticks added"+RT);
		F.f.item.add("Soyasticks");
		F.f.cost.add(45);
	}
	public void peanutchikki(){
		System.out.println(G+"1 Peanutchikki added"+RT);
		F.f.item.add("Peanutchikki");
		F.f.cost.add(100);
	}
	public void kitkat(){
		System.out.println(G+"1 Kitkat added"+RT);
		F.f.item.add("Kitkat");
		F.f.cost.add(25);
	}
	public void fivestar(){
		System.out.println(G+"1 Fivestar added"+RT);
		F.f.item.add("Fivestar");
		F.f.cost.add(150);
	}
	public void ladoo(){
		System.out.println(G+"1Kg Ladoo added"+RT);
		F.f.item.add("Ladoo");
		F.f.cost.add(148);
	}
	public void aloobhujia(){
		System.out.println(G+"1Pack Aloobhujia added"+RT);
		F.f.item.add("Aloobhujia");
		F.f.cost.add(55);
	}
	public void goobles(){
		System.out.println(G+"1Pack Goobles added"+RT);
		F.f.item.add("Goobles");
		F.f.cost.add(60);
	}
	public void darkfantasy(){
		System.out.println(G+"1Pack Darkfantasy added"+RT);
		F.f.item.add("Darkfantasy");
		F.f.cost.add(67);
	}
	public void bourbon(){
		System.out.println(G+"1Pack Bourbon added"+RT);
		F.f.item.add("Bourbon");
		F.f.cost.add(80);
	}
	public void britannia(){
		System.out.println(G+"1Pack Britannia added"+RT);
		F.f.item.add("Britannia");
		F.f.cost.add(154);
	}
	public void parle(){
		System.out.println(G+"1Pack Parle added"+RT);
		F.f.item.add("Parle");
		F.f.cost.add(137);
	}
	public void sunfeast(){
		System.out.println(G+"1Pack Sunfeast added"+RT);
		F.f.item.add("Sunfeast");
		F.f.cost.add(106);
	}
	public void brownie(){
		System.out.println(G+"1 Brownie added"+RT);
		F.f.item.add("Brownie");
		F.f.cost.add(67);
	}
	public void unibic(){
		System.out.println(G+"1Pack Unibic added"+RT);
		F.f.item.add("Unibic");
		F.f.cost.add(87);
	}
	public void cakes(){
		System.out.println(G+"1Pack Cakes added"+RT);
		F.f.item.add("Cakes");
		F.f.cost.add(126);
	}
	public void chocorolls(){
		System.out.println(G+"1Pack Chocorolls added"+RT);
		F.f.item.add("Chocorolls");
		F.f.cost.add(98);
	}
	public void chocopie(){
		System.out.println(G+"1Pack Chocopie added"+RT);
		F.f.item.add("Chocopie");
		F.f.cost.add(129);
	}

}