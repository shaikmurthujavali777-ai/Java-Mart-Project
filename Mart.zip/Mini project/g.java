import java.util.ArrayList;
import P3.grocery_items;
public class g extends grocery_items{
	public static final String G = "\u001B[32m";
	public static final String RT = "\u001B[0m";
	@Override
	public void rice(){
		System.out.println(G+"1kg rice added"+RT);
		F.f.item.add("Rice");
		F.f.cost.add(75);
	}
	@Override
	public void wheatFlour(){
		System.out.println(G+"1kg wheatFlour added"+RT);
		F.f.item.add("Wheat Flour");
		F.f.cost.add(70);
	}
	@Override
	public void sugar(){
		System.out.println(G+"1kg Sugar added"+RT);
		F.f.item.add("Sugar");
		F.f.cost.add(47);
	}
	@Override
	public void salt(){
		System.out.println(G+"1kg salt added"+RT);
		F.f.item.add("Salt");
		F.f.cost.add(30);
	}
	@Override
	public void cookingOil(){
		System.out.println(G+"1litre Cooking Oil added"+RT);
		F.f.item.add("Cooking Oil");
		F.f.cost.add(160);
	}
	@Override
	public void turmericpowder(){
		System.out.println(G+"500g Turmeric Powder added"+RT);
		F.f.item.add("Turmeric Powder");
		F.f.cost.add(110);
	}
	@Override
	public void redchillipowder(){
		System.out.println(G+"500g Red Chilli Powder added"+RT);
		F.f.item.add("Red Chilli Powder");
		F.f.cost.add(250);
	}
	@Override
	public void mustardSeeds(){
		System.out.println(G+"200g Mustard Seeds added"+RT);
		F.f.item.add("Mustard Seeds");
		F.f.cost.add(50);
	}
	@Override
	public void milk(){
		System.out.println(G+"1litre Milk added"+RT);
		F.f.item.add("Milk");
		F.f.cost.add(80);
	}
	@Override
	public void teaPowder(){
		System.out.println(G+"100g Tea Powder added"+RT);
		F.f.item.add("Tea Powder");
		F.f.cost.add(90);
	}
	@Override
	public void curd(){
		System.out.println(G+"500g Curd added"+RT);
		F.f.item.add("Curd");
		F.f.cost.add(50);
	}
	@Override
	public void bread(){
		System.out.println(G+"500g Bread added"+RT);
		F.f.item.add("Bread");
		F.f.cost.add(60);
	}
	@Override
	public void eggs(){
		System.out.println(G+"12 pieces Eggs added"+RT);
		F.f.item.add("Eggs");
		F.f.cost.add(90);
	}
	@Override
	public void detergentPowder(){
		System.out.println(G+"1kg Detergent Powder added"+RT);
		F.f.item.add("Detergent Powder");
		F.f.cost.add(70);
	}
	@Override
	public void toothPaste(){
		System.out.println(G+"150g Tooth Paste added"+RT);
		F.f.item.add("Tooth Paste");
		F.f.cost.add(100);
	}
	@Override
	public void paneer(){
		System.out.println(G+"200g Paneer added"+RT);
		F.f.item.add("Paneer");
		F.f.cost.add(190);
	}
	@Override
	public void  vermicelli(){
		System.out.println(G+"400g  VermiCelli added"+RT);
		F.f.item.add(" VermiCelli");
		F.f.cost.add(37);
	}
	@Override
	public void  chicken(){
		System.out.println(G+"1kg Chicken added"+RT);
		F.f.item.add("Chicken");
		F.f.cost.add(300);
	}
	@Override
	public void  chickenMasala(){
		System.out.println(G+"100g Chicken Masala added"+RT);
		F.f.item.add("Chicken Masala");
		F.f.cost.add(38);
	}
	 @Override
	public void  noodles(){
		System.out.println(G+"95g Noodles added"+RT);
		F.f.item.add("Noodles");
		F.f.cost.add(20);
	}
}


	 
	





	

	



	




	




	

	


	









