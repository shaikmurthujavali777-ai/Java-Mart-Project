               
import java.util.ArrayList;
import P1.fruit_items;
public class F extends fruit_items{	
	public static final String G = "\u001B[32m";
	public static final String RT = "\u001B[0m";
	static Arraylist f= new Arraylist();
	@Override
	public void apple(){
		System.out.println(G+"1Kg Apples added"+RT);
		f.item.add("Apple");
		f.cost.add(200);
	}
	@Override
	public void orange(){
		System.out.println(G+"1kg Oranges added"+RT);
		f.item.add("Orange");
		f.cost.add(70);
	}
	@Override
	public void grapes(){
		System.out.println(G+"1kg Grapes added"+RT);
		f.item.add("Grapes");
		f.cost.add(90);
	}
	@Override
	public void bananas(){
		System.out.println(G+"1 dozen Bananas added"+RT);
		f.item.add("Bananas");
		f.cost.add(50);
	}
	@Override
	public void avocado(){
		System.out.println(G+"1kg Avocado added"+RT);
		f.item.add("Avocado");
		f.cost.add(240);
	}
	@Override
	public void watermelon(){
		System.out.println(G+"1 Watermelon added"+RT);
		f.item.add("Watermelon");
		f.cost.add(70);
	}
	@Override
	public void cherries(){
		System.out.println(G+"1kg Cherries added"+RT);
		f.item.add("Cherries");
		f.cost.add(620);
	}
	@Override
	public void kiwi(){
		System.out.println(G+"1kg Kiwi added"+RT);
		f.item.add("Kiwi");
		f.cost.add(650);
	}
	@Override
	public void mangoes(){
		System.out.println(G+"1kg Mangoes added"+RT);
		f.item.add("Mangoes");
		f.cost.add(150);
	}
	@Override
	public void pineapple(){
		System.out.println(G+"1 Pineapple added"+RT);
		f.item.add("Pineapple");
		f.cost.add(60);
	}
	@Override
	public void guava(){
		System.out.println(G+"1kg Guava added"+RT);
		f.item.add("Guava");
		f.cost.add(25);
	}
	@Override
	public void papaya(){
		System.out.println(G+"1kg Papaya added"+RT);
		f.item.add("Papaya");
		f.cost.add(30);
	}
	@Override
	public void promogranate(){
		System.out.println(G+"1kg Promogranate added"+RT);
		f.item.add("Promogranate");
		f.cost.add(150);
	}
	@Override
	public void muskmelon(){
		System.out.println(G+"1kg Muskmelon added"+RT);
		f.item.add("Muskmelon");
		f.cost.add(15);
	}
	@Override
	public void dragonfruit(){
		System.out.println(G+"1kg Dragonfruits added"+RT);
		f.item.add("Dragonfruits");
		f.cost.add(200);
	}
	@Override
	public void blueberry(){
		System.out.println(G+"1kg Blueberry added"+RT);
		f.item.add("Blueberry");
		f.cost.add(800);
	}
	@Override
	public void mosambi(){
		System.out.println(G+"1kg Mosambi added"+RT);
		f.item.add("Mosambi");
		f.cost.add(60);
	}
	public void strawberry(){
		System.out.println(G+"1kg Strawberry added"+RT);
		f.item.add("Strawberry");
		f.cost.add(400);
	}
	public void jackfruit(){
		System.out.println(G+"1kg Jackfruit added"+RT);
		f.item.add("Jackfruit");
		f.cost.add(60);
	}
	public void custardapple(){
		System.out.println(G+"1kg Custardapple added"+RT);
		f.item.add("Custardapple");
		f.cost.add(150);
	}
	
	
}